<script lang="ts" setup>
import consoleTable from "../console/components/consoleTable.vue";
</script>

<template>
  <div>
    <consoleTable tag_id="12" />
  </div>
</template>
