<script setup>
const props = defineProps(["scope"]);


</script>