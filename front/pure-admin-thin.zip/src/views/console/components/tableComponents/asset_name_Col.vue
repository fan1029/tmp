<script setup lang="ts">
import { defineProps, ref } from "vue";
import { Link, ChatDotSquare, Select, Refresh } from "@element-plus/icons-vue";
import { useNoteStore } from "@/store/modules/note";
const props = defineProps({
  scope: {
    type: Object,
    required: true
  }
});

function openNoteSmall(id: number) {
  useNoteStore().setCurrentNoteId(id);
  useNoteStore().setCurrentNoteName(props.scope.row.asset_name);
}
</script>
<template>
  <div style="display: flex; align-items: center">
    <span style="font-size: 20">{{ scope.row.asset_name }}</span>
    <el-icon
      @click="openNoteSmall(scope.row.id)"
      size="15"
      style="vertical-align: middle; margin-left: 10px"
    >
      <svg
        version="1.0"
        xmlns="http://www.w3.org/2000/svg"
        width="512.000000pt"
        height="512.000000pt"
        viewBox="0 0 512.000000 512.000000"
        preserveAspectRatio="xMidYMid meet"
      >
        <g
          transform="translate(0.000000,512.000000) scale(0.100000,-0.100000)"
          fill="#000000"
          stroke="none"
        >
          <path
            d="M955 5113 c-272 -39 -515 -225 -623 -479 -66 -156 -62 -20 -62 -2074
0 -2054 -4 -1918 62 -2074 78 -183 218 -327 400 -410 148 -69 150 -69 608 -73
285 -3 427 -1 452 6 142 43 186 236 76 338 -54 51 -71 53 -461 53 -206 0 -388
4 -418 10 -118 22 -226 107 -282 220 l-32 65 0 1865 0 1865 32 65 c56 113 164
198 282 220 35 6 497 10 1306 10 809 0 1271 -4 1306 -10 118 -22 226 -107 282
-220 l32 -65 5 -690 c4 -488 8 -697 17 -716 72 -161 285 -172 364 -17 18 36
19 69 19 728 0 599 -2 700 -16 762 -67 294 -277 513 -579 604 -56 17 -138 18
-1400 20 -737 1 -1353 -1 -1370 -3z"
          />
          <path
            d="M1180 3898 c-24 -13 -58 -40 -74 -61 -29 -36 -31 -45 -31 -117 0 -72
2 -81 31 -117 16 -21 50 -48 74 -60 l44 -23 1068 0 c942 0 1073 2 1106 15 163
69 163 301 0 370 -33 13 -164 15 -1106 15 l-1068 0 -44 -22z"
          />
          <path
            d="M1180 3098 c-24 -13 -58 -40 -74 -61 -29 -36 -31 -45 -31 -117 0 -72
2 -81 31 -117 16 -21 50 -48 74 -60 l44 -23 1068 0 c942 0 1073 2 1106 15 163
69 163 301 0 370 -33 13 -164 15 -1106 15 l-1068 0 -44 -22z"
          />
          <path
            d="M4125 2385 c-71 -16 -143 -47 -205 -88 -63 -41 -1197 -1174 -1220
-1217 -10 -20 -73 -216 -140 -435 -110 -362 -121 -406 -118 -462 3 -51 9 -69
34 -100 45 -56 107 -86 169 -79 46 4 693 179 845 228 l65 21 573 571 c607 604
648 651 693 783 20 57 24 88 24 193 0 151 -20 221 -96 335 -136 203 -386 303
-624 250z m203 -400 c136 -57 165 -233 55 -337 l-29 -28 -139 140 -139 139 29
32 c60 63 148 85 223 54z m-623 -1015 l-370 -369 -199 -55 c-110 -31 -201 -54
-202 -53 -1 1 25 90 58 197 l59 195 372 367 372 366 140 -139 140 -139 -370
-370z"
          />
          <path
            d="M1180 2298 c-24 -13 -58 -40 -74 -61 -29 -36 -31 -45 -31 -117 0 -72
2 -81 31 -117 16 -21 50 -48 74 -60 l44 -23 666 0 c626 0 667 2 705 19 157 73
157 289 0 362 -38 17 -79 19 -705 19 l-666 0 -44 -22z"
          />
        </g></svg
    ></el-icon>

    <div v-if="scope.row.runningInfo.length > 0">
      <el-tooltip class="box-item" effect="light" placement="right" raw-content>
        <template #content>
          <span
            v-for="(statusInfo, index) in scope.row.runningInfo"
            :key="index"
            >{{ statusInfo.runningPlugin }}:
            {{ statusInfo.running ? "运行中" : "队列中" }}<br
          /></span>
        </template>
        <div style="margin-left: 10px">
          <el-icon
            id="LoadingIcon"
            style="color: rgb(52, 73, 255); vertical-align: middle"
            size="17"
            ><Refresh
          /></el-icon>
        </div>
      </el-tooltip>
    </div>
  </div>
</template>
<style scoped>
#LoadingIcon {
  animation: rotation 2s infinite linear;
}
@keyframes rotation {
  from {
    transform: rotate(359deg);
  }
  to {
    transform: rotate(0);
  }
}
</style>
