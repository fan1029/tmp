<script setup lang="ts">
import EditorJS from "@editorjs/editorjs";
const editor = new EditorJS("editorjs");
</script>
<template>
  <div id="editorjs" />
</template>
